<?php
$graph_nid = $row->nid;
$node = node_load($graph_nid);
if($node->type == "sketch") {
$current_graph_data ='';
if (!empty($node->field_graph)) {
    $current_graph_data  = $node->field_graph['und'][0]['value'];
}

drupal_add_css("sites/all/themes/news/css/joint.css", $type = 'file', $media = 'all', $preprocess = FALSE);
drupal_add_css("sites/all/themes/news/css/style.css", $type = 'file', $media = 'all', $preprocess = FALSE);
drupal_add_js("sites/all/themes/news/js/lodash.min.js", array('type' => 'file', 'scope' => 'header', 'weight' => 1), $preprocess = FALSE);
drupal_add_js("sites/all/themes/news/js/backbone-min.js", array('type' => 'file', 'scope' => 'header', 'weight' => 2), $preprocess = FALSE);
drupal_add_js("sites/all/themes/news/js/joint.js", array('type' => 'file', 'scope' => 'header', 'weight' => 3), $preprocess = FALSE);
drupal_add_library('system', 'ui.draggable');
drupal_add_library('system', 'ui.droppable');
?>

<div class="container-fluid">
   <div class="row">
      <div id="operator-rel" class="closed">
      
        <div id="operator-area">

          <div id="search-box">
            <form>
              <div class="form-group">
                <input type="text" name="searchOperator" class="form-control" id="searchOperator" placeholder="Search operator" value="">
              </div>
            </form>
          </div>
        <div id="stencil">
        <?php 
          $main_array = array();
          $op_array = array();
          $opId = array();
          $field_input_port = '';
          $field_output_port = '';
          $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'node')
              ->entityCondition('bundle', 'pallet')
              ->propertyCondition('status', 1);
            $result = $query->execute();

            if (!empty($result['node'])) {
              $nids = array_keys($result['node']);  
             foreach ($nids as $nid) {
                $node_pallet = node_load($nid, NULL, TRUE);
                $pallet_title = $node_pallet->title;
                $pallet_nid = $node_pallet->nid;
                $operator_nid = $node_pallet->field_operator['und'];
                echo '<div id="pallet"><div class="panel-group">
                        <div class="panel panel-default">
                          <div class="panel-heading">
                            <h4 class="panel-title">
                              <a data-toggle="collapse" href="#'.$pallet_title.'">'.$pallet_title.'</a>
                            </h4>
                          </div>
                          <div id="'.$pallet_title.'" class="panel-collapse collapse">
                            <ul class="list-group">';
               $op_array2 = array();
               $op_i = 0;
               foreach ($operator_nid as $value) {
                  

                    $op_id =  $value['target_id'];
                    $op_node = node_load($op_id);
                    $op_title = $op_node->title;
                    $op_nid = $op_node->nid;
                    $fill_color = $op_node->field_fill_color['und'][0]['rgb'];
                    //drupal_set_message("<pre>".print_r($file_name,true)."</pre>");
                    // if(!empty($op_node->field_parameters)) {
                    //   $file_path= $op_node->field_parameters['und'][0]['value'];
                    // }
                    if(!empty($op_node->field_input_port)) {
                      $field_input_port = $op_node->field_input_port['und'][0]['value'];
                    }
                    if(!empty($op_node->field_output_port)) {
                      $field_output_port = $op_node->field_output_port['und'][0]['value'];
                    }
                    
                    $field_operator_icon = $op_node->field_operator_icon['und'][0]['filename'];
                    echo "<li style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none;' 
 unselectable='on'
 onselectstart='return false;' 
 onmousedown='return false;' class='list-group-item filterdrag' id=$op_nid value=$op_nid>".$op_title."</li>";

                    $op_array[$op_nid] 
                           = array(
                              "dLabel" => $op_title,
                              "dInPorts" => $field_input_port,
                              "dOutPorts" => $field_output_port,
                              "imagePath" => $field_operator_icon,
                              "fillClr" => $fill_color
                    );

                    $op_array2[$op_i] = array('title' => $op_title, 'op_nid' => $op_nid, 'pallet' => $pallet_title);
                    $op_i++;
               }
               echo "</ul></div></div></div></div>";
               $main_array[] = array(
                        "title" => $pallet_title,
                        "operators" => $op_array2
                        );    
              }

            }
        ?>
        
        </div>
        </div>
      <div class="user-nav-slide"></div> 
      </div>
         <div id="parameter-rel" class="closed">
      
        <div id="parameter-area">

          <div id="parameters-box">
            <form>
              <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="titleOperator" id="titleOperator" placeholder="Operator title">
              </div>
              <div class="form-group">
                <label>Fill color</label>
                <input type="text" class="form-control" name="fillColor" id="fillColor" placeholder="Change color ie #bababa">
              </div>
              <div class="form-group" id="paraFilePath" style="display:none;">
                <label>File Path</label>
                <input type="text" class="form-control" name="filePathVal" id="filePathVal" value="">
                <input type="button" style='margin-top: 5px;' class='btn btn-default' value="Modify" id="btn-modify">
              </div>
              <div class="form-group" id="paraAttrName" style="display:none;">
                <label>Attribute Name</label>
                <select class="form-control" id="attributeName" >
                   <option>Age</option>
                   <option>Sex</option>
                </select>
              </div>
              <div class="form-group" id="paraSortingDirection" style="display:none;">
              <label>Sorting Direction</label>
                <select class="form-control" id="sortingDirection">
                   <option>increasing</option>
                   <option>decreasing</option>
                </select>
              </div>
              <div class="form-group" id="filterDiv" style="display:none;">
                <label>Filters</label>
                <input type="button" style='margin-top: 5px;' class='btn btn-default' value="Add filter" id="btn-filter-form">
              </div>
              <div class="form-group" id="decisionTreeDiv" style="display:none;">
                <label>Criterion</label>
                <select class="form-control" id="">
                   <option>gain_ratio</option>
                   <option>information_gain</option>
                </select>
                <label>Maximal depth</label>
                <input type="text" class="form-control" name="" id="">
                <input type="checkbox" class="parameter-checkbox" name="" id="">
                <label>Apply Pruning</label><br>
                <label>Confidence</label>
                <input type="text" class="form-control" name="" id="">
                <input type="checkbox" class="parameter-checkbox" name="" id="">
                <label>Apply rePruning</label><br>
                <label>Minimal gain</label>
                <input type="text" class="form-control" name="" id="">
                <label>Minimal leaf size</label>
                <input type="text" class="form-control" name="" id="">
              </div>
              <div class="form-group" id="joinDiv" style="display:none;">
                <label>Join Type</label>
                <select class="form-control" id="joinTypeId">
                   <option>inner</option>
                   <option>outer</option>
                   <option>left</option>
                   <option>right</option>
                </select>
                <div class="form-group">
                <input type="checkbox" class="parameter-checkbox" name="" id="">
                <label>Use id attribute as key</label>
                </div>
              </div>
              <input type="hidden" class="form-control" name="param-id" id="param-id" value="">
            </form>
          </div>
        <div id="parameters">
          <div>
          <p>Click on an operator to change its properties.</p>
          </div>
        </div>
        </div>
        <div class="user-nav-slide-right"></div> 
      </div>        
   </div>
    <div class="row">
      <div>
       <!-- Modal export-->
        <div class="modal fade" id="expModal" role="dialog">
            <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Export JSON</h4>
                </div>
                <div class="modal-body">
                  <div id="jsonOutId">
                    <textarea id="expTxt" class="form-control"></textarea>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" id="copyToClip">Copy to clipboard</button>
                </div>
              </div>
              
            </div>
        </div>
            <!-- Modal Import-->
        <div class="modal fade" id="impModal" role="dialog">
            <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Import JSON</h4>
                </div>
                <div class="modal-body">
                  <div id="jsonInId">
                    <textarea id="impTxt" class="form-control"></textarea>
                    <button id="btn-import-json" class="btn btn-default">Import</button>
                  </div>
                </div>
              </div>   
            </div>
        </div>
        <div class="modal fade" id="msgModal" role="dialog">
            <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-body">
                  <div id="msgSaveId">
                  <h6>Sketch saved successfully.</h6>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <div class="modal fade" id="filterModal" role="dialog">
            <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Create Filters</h4>
                </div>
                <div class="modal-body">
                  <div id="filterInId">
                  <form>
                    <table>
                    <tr>
                    <td class="popupFiltertd">
                      <div class="form-group">
                        <select class="form-control" id="sourceAttrFilter">
                         
                        </select>
                      </div>
                    </td>
                    <td class="popupFiltertd">
                      <div class="form-group">
                        <select class="form-control" id="applyFilter">
                           <option>equal</option>
                           <option>not equal</option>
                           <option>contains</option>
                        </select>
                      </div>
                    </td>
                    <td class="popupFiltertd">
                      <div class="form-group">
                        <input type="text" class="form-control" name="enterFilterValue" id="enterFilterValue">
                      </div>
                    </td>                                       
                    </tr>
                    <tr>
                      <td>
                        <input type="button" class="btn btn-default filterBtns" value="ok" id="btn-filter-ok">
                        <input type="button" class="btn btn-default filterBtns" value="cancel" id="btn-filter-cancel">
                      </td>
                    </tr>
                    </table>
                  </form>

                  </div>
                </div>
              </div>   
            </div>
        </div>
        <div id="paper">
        </div>
      </div>
    </div>
</div>
 <script type="text/javascript">
  //Function start
jQuery(function () {
//code for serach operator
jQuery('input[name="searchOperator"]').on('keyup', function() {

    var searchVal = jQuery(this).val();
    var mainArray = <?php echo (json_encode($main_array,true));?>;
    var myNewArray = [];
    var MyObj = {
      filter : function() {
          var tmpPalltets = [];
          var pallet = {};
          var operator = {};
          for(var i=0;i<this.pallets.length;i++) {
              pallet = this.pallets[i];
              if (pallet.title.search(new RegExp(searchVal, "i")) != -1) {
                  tmpPalltets.push(pallet);
                  continue;
              } else {
                for(var j=0;j<pallet.operators.length;j++) {
                  operator = pallet.operators[j];
                  if (operator.title.search(new RegExp(searchVal, "i")) != -1) {
                   tmpPalltets.push({"title": pallet.title, "operators": [{"op_nid":operator.op_nid, "pallet": operator.pallet, "title":operator.title}]});
                   break;
                  }
                }
              }
          }
          this.pallets = tmpPalltets;
        return this;
      },
      pallets: mainArray
  };
MyObj.filter();
var resultHtml = '';
for(var i=0;i<MyObj.pallets.length;i++) {
   resultHtml += '<div id="pallet"><div class="panel-group"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" href="#'+MyObj.pallets[i].title+'" class="bootstrap-collapse-processed" aria-expanded="true">'+MyObj.pallets[i].title+'</a></h4></div><div id="'+MyObj.pallets[i].title+'" class="panel-collapse collapse in" aria-expanded="true"><ul class="list-group">';
                            for(var j=0;j<MyObj.pallets[i].operators.length;j++) {
                              resultHtml += '<li class="list-group-item" id="'+MyObj.pallets[i].operators[j].op_nid+'" value="'+MyObj.pallets[i].operators[j].op_nid+'">'+MyObj.pallets[i].operators[j].title+'</li>';
                            }
                            resultHtml += '</ul></div></div></div></div>';
}
jQuery('#stencil').html(resultHtml);
});

  var cntrlIsPressed = false;
    jQuery(document).keydown(function(event){
    if(event.which=="17")
        cntrlIsPressed = true;    
    });

  jQuery(document).keyup(function(){
      cntrlIsPressed = false;
  });
  var selectedCells = [];
// Define Custom Model with background image and ports
// Canvas where shape are dropped
var graph = new joint.dia.Graph,
  paper = new joint.dia.Paper({
    el: jQuery('#paper'),
    model: graph,
    gridSize: 8,
    drawGrid:true,
    linkPinning: false,
    defaultLink: new joint.dia.Link({
      router: { name: 'manhattan' },
      connector: { name: 'rounded' },
      attrs: {
        '.connection': {
          stroke: '#b9c0c0',
          'stroke-width': 2
      },
    },
    }),
    validateConnection: function(cellViewS, magnetS, cellViewT, magnetT, end, linkView) {
    // Prevent linking from input ports.
    if (magnetS && magnetS.getAttribute('port-group') === 'in') return false;
      // Prevent linking from output ports to input ports within one element.
    if (cellViewS === cellViewT) return false;
    // Prevent linking to input ports.
    return magnetT && magnetT.getAttribute('port-group') === 'in';
    },
    validateMagnet: function(cellView, magnet) {
        // Disable linking interaction for magnets marked as passive (see below `.inPorts circle`).
        return magnet.getAttribute('magnet') !== 'passive';
    },
    //Prevent adding vertex by clicking on link
    interactive: function(cellView) {
        if (cellView.model instanceof joint.dia.Link) {
            // Disable the default vertex add functionality on pointerdown.
            return { vertexAdd: false };
        }
        return true;
    },
    snapLinks: { radius: 75 },
    // Enable marking available cells & magnets
    markAvailable: true
  });

////customshape
joint.shapes.devs.MyImageModel = joint.shapes.devs.Model.extend({

  markup: '<g class="rotatable"><g class="scalable"><rect/><image/></g><text/></g>',

  defaults: joint.util.deepSupplement({

    type: 'devs.MyImageModel',
    size: {width: 100, height: 60},
    attrs: {
        rect: { fill: '#e8f1f0',stroke: '#a2a8a8',width: 100, height: 60},
        image: {width: 50, height: 20 }
    }
  }, joint.shapes.devs.Model.prototype.defaults)
});

joint.shapes.devs.MyImageModelView = joint.shapes.devs.ModelView;

// Canvas from which you take shapes
jQuery('#stencil').on('mousedown', 'li', function(e){

    jQuery('#stencil').on('mousemove', 'li', function(e){
      if (e.offsetX > 100) {
        drawShape(e, jQuery(this).attr("id"));
        jQuery('#stencil').off('mousemove' , 'li');
      }

    });

});
// jQuery(".filterdrag").draggable({
//     helper: "clone",
//     cursor: 'move',
//     revert: 'invalid',
//     opacity: "0.5"

// });
// jQuery("#paper").droppable({
//     accept: jQuery(".filterdrag"),
//     hoverClass: "dropHover",
//     drop: function (e, li) {

//          var me = li.draggable.clone();
//         // me.appendTo(this);
//         drawShape(e, jQuery(this).attr("id"));
	
//     }
// });
function drawShape(ev, id) {

  dInPorts = new Array();
  dOutPorts = new Array();
  jsArray =  new Array();
  jsIndexArray =  new Array();
  var dLabel, dInPorts, dOutPorts, imagePath, fillClr;
  var jsIndexArray = <?php echo (json_encode($opId));?>;
  var index = jsIndexArray.indexOf(id);
  var operatorId =  jsIndexArray[index];
  var jsArray = <?php echo (json_encode($op_array,true));?>;
  var dLabel = jsArray[id].dLabel;
  var inPortsArray = jsArray[id].dInPorts;
  var fillClr = jsArray[id].fillClr;
  //var filePath = jsArray[id].filePath;
  //console.log("test"+filePath);
  var imagePath =  jsArray[id].imagePath; 
    if (inPortsArray) {
      var dInPorts = inPortsArray.split(',');
    }
  var outPortsArray = jsArray[id].dOutPorts;
  if (outPortsArray) {
      var dOutPorts = outPortsArray.split(',');
    }
  imgPath = '/sites/default/files/'+imagePath;

  jQuery('body').append('<div id="flyPaper" style="position:fixed;z-index:100;opacity:.7;pointer-event:none;"></div>');
  var flyGraph = new joint.dia.Graph,
    flyPaper = new joint.dia.Paper({
      el: jQuery('#flyPaper'),
      model: flyGraph,
      interactive: false
    }),
  flyShape = new joint.shapes.devs.MyImageModel({
  position: { x: 10, y: 10 },
    size: {width: 100, height: 60},
    inPorts: dInPorts,
    operatorType: dLabel,
    outPorts: dOutPorts,
    filePath: 'sites/default/files/sourcefiles',
    ports: {
        groups: {
            'in': {
                position: 'top',
                label: {
                  position: 'outside'
                },
                attrs: {
                    '.port-body': {
                        fill: '#ccd6d6',
                        magnet: 'passive',
                        r:5,
                        stroke:'#a2a8a8'
                      },
                      '.port-label':{
                        'font-size': 9
                      }
                }
            },
            'out': {
                position: 'bottom',
                label: {
                  position: 'outside'
                },
                attrs: {
                    '.port-body': {
                        fill: '#ccd6d6',
                        r:5,
                        stroke:'#a2a8a8'
                    },
                    '.port-label':{
                      'font-size': 9,
                    },
                    require:true
                }
            },
        }
    },
    attrs: {
        '.label': { text: dLabel , 'ref-x': .5, 'ref-y': .2},
        text: { text: dLabel, fill: '#000000','ref-y': -30,'font-size': 9},
        rect: { fill: '#e8f1f0',stroke: '#a2a8a8',width: 100, height: 60},
        image: { 'xlink:href': imgPath,'ref-x': 25, 'ref-y': 20,ref: 'rect',width: 50, height: 20 }
    }
}),
    pos = {x: ev.pageX, y: ev.pageY},
    offset = {
      x: ev.offsetX,
      y: ev.offsetY
    };

  flyShape.position(0, 0);
  flyGraph.addCell(flyShape);
  jQuery("#flyPaper").offset({
    left: ev.pageX - offset.x,
    top: ev.pageY - offset.y
  });
  jQuery('body').on('mousemove.fly', function(e) {
    jQuery("#flyPaper").offset({
      left: e.pageX - offset.x,
      top: e.pageY - offset.y
    });
  });
  jQuery('body').on('mouseup.fly', function(e) {
    var x = e.pageX,
        y = e.pageY,
      target = paper.$el.offset();
    // Dropped over paper ?
    if (x > target.left && x < target.left + paper.$el.width() && y > target.top && y < target.top + paper.$el.height()) {
      var s = flyShape.clone();
      s.position(x - target.left - offset.x, y - target.top - offset.y);
      graph.addCell(s);
    }
    jQuery('body').off('mousemove.fly').off('mouseup.fly');
    flyShape.remove();
    jQuery('#flyPaper').remove();
  });
    
}

//paper blank click
paper.on('blank:pointerdown', function(cellView, evt) {
  jQuery(".user-nav-slide-right").animate({"right": "0px"});
  jQuery("#parameter-area").hide('medium');
  jQuery("#parameter-rel").addClass("closed");
});
//CLICK ON A CELL TO SELECT IT 
   
paper.on('cell:pointerdown', function(cellView, evt, x, y) {
    //console.log(cellView);
    if(cntrlIsPressed) {
      var select_el = cellView.el;
      V(select_el).toggleClass('selected');
      var ew = select_el.getAttribute("class");
      
      if(~ew.indexOf("selected")){
        selectedCells.push(graph.getCell(cellView.model.id));
      }
      else{
        selectedCells = selectedCells.filter(function(el) {
          return el.id !== cellView.model.id;
        });
      }
    }
    else{
      if (cellView.model.isLink()) {
        jQuery(".user-nav-slide-right").animate({"right": "0px"});
        jQuery("#parameter-area").hide('medium');
        jQuery("#parameter-rel").addClass("closed");
      }

    else{
      //change parameters
      var currOpId = cellView.model.id
      var filePathVal = cellView.model.attributes.filePath;
      var opTypeVal = cellView.model.attributes.operatorType;
      //console.log(modelattr);
      var currTitle = cellView.model.attr('text/text');
      if(opTypeVal == 'Source'){
        jQuery('#paraFilePath').show();
        jQuery('#filePathVal').val(filePathVal);
        jQuery('#paraAttrName, #filterDiv, #paraSortingDirection, #decisionTreeDiv, #joinDiv').hide();
      }
      else if(opTypeVal == 'Sort'){
        jQuery('#paraAttrName').show();
        jQuery('#paraFilePath, #filterDiv, #paraSortingDirection, #decisionTreeDiv, #joinDiv').hide();
      }
      else if(opTypeVal == 'Filter'){
        jQuery('#filterDiv').show();
        jQuery('#paraFilePath, #paraAttrName, #paraSortingDirection, #decisionTreeDiv, #joinDiv').hide();

      }
      else if(opTypeVal == 'Decision Tree'){
        jQuery('#decisionTreeDiv').show();
        jQuery('#paraFilePath, #paraAttrName, #paraSortingDirection, #filterDiv, #joinDiv').hide();
      }
      else if(opTypeVal == 'Joins'){
        jQuery('#joinDiv').show();
        jQuery('#paraFilePath, #paraAttrName, #paraSortingDirection, #filterDiv, #decisionTreeDiv').hide();
      }
      else{
        jQuery('#paraFilePath, #paraAttrName, #paraSortingDirection, #filterDiv, #decisionTreeDiv,#joinDiv').hide();
      }
      var currFillColor = cellView.model.attr('rect/fill');
      jQuery(".user-nav-slide-right").animate({"right": "232px"});
      jQuery("#parameter-area").show('medium');
      jQuery("#parameters-box").show('medium');
      jQuery("#parameters").hide();
      jQuery("#parameter-rel").removeClass("closed");
      jQuery('#titleOperator').val(currTitle);
      jQuery('#fillColor').val(currFillColor);
      jQuery('#param-id').val(currOpId);
      jQuery('input[name="titleOperator"]').on('keyup', function() {
        var paramHiddenId = document.getElementById("param-id").value;
        if(paramHiddenId == currOpId){
          var rel1 = document.getElementById("titleOperator").value;
          cellView.model.attr('text/text', rel1);
        }
      });
      jQuery('input[name="fillColor"]').on('keyup', function() {
        var paramHiddenId = document.getElementById("param-id").value;
        if(paramHiddenId == currOpId){
          var rel2 = document.getElementById("fillColor").value;
          cellView.model.attr('rect/fill', rel2);
        }
      });
    }
    }
  });

jQuery(document).keydown(function(event){
  //Delete cell
  if(event.which=="46")
    _.each(selectedCells, function(selectedCell) {
        var currentParentID = selectedCell.get('parent');
    
        selectedCell.remove();
        if(currentParentID){
          var currentParentCell = graph.getCell(currentParentID);
          var numberOfChilds = currentParentCell.getEmbeddedCells({deep: true});
          if(numberOfChilds === undefined || numberOfChilds.length == 0) {
            currentParentCell.remove();
          }
        }
        selectedCells = [];
  });
    //copy cell
  if(event.which=="67")
    _.each(selectedCells, function(selectedCell) {
      var clone = selectedCell.clone();
      graph.addCell(clone);
         
  }) 
});
//clear grpah
jQuery('#btn-clear').on('click', _.bind(graph.clear, graph));
//Grouping / Ungrouping
var rect = joint.shapes.basic.Rect;
jQuery('#btn-group').click(function () {
  if (selectedCells === undefined || selectedCells.length == 0) return;
    var parent = element(rect);
    _.each(selectedCells, function(selectedCell) {
        parent.embed(selectedCell);
        parent.fitEmbeds({deep:true,
          padding:10});
        parent.toFront({ deep: true });
        V(paper.findViewByModel(selectedCell).el).removeClass('selected');
        selectedCells=[];
    });
});
jQuery('#btn-ungroup').click(function () {
   if (selectedCells === undefined || selectedCells.length == 0) return;
   
   _.each(selectedCells, function(selectedCell) {

      var numberOfChilds = selectedCell.getEmbeddedCells({deep: true});
      if(numberOfChilds.length > 0){
        _.each(numberOfChilds, function(children) {
          selectedCell.unembed(children);
        });
        selectedCell.remove();
        selectedCells = selectedCells.filter(function(el) {
          return el.id !== selectedCell.id;
        });
      }
    });
});
//Export
jQuery('#btn-export').click(function () {
  jQuery("#expModal").modal("show");
  var jsonOut =JSON.stringify(graph);
  jQuery('#expTxt').empty();
  jQuery('#expTxt').append(jsonOut);
});
jQuery('#copyToClip').click(function () {
   jQuery("#expTxt").select();
    document.execCommand('copy');
});
jQuery('#expTxt').focus(function() {
    var $this = jQuery(this);
    $this.select();
    $this.mouseup(function() {
        $this.unbind("mouseup");
        return false;
    });
});
jQuery('#btn-import').click(function () {
  jQuery("#impModal").modal("show");
});
jQuery('#btn-import-json').click(function () {
  var rel = document.getElementById("impTxt").value;
  graph.fromJSON(JSON.parse(rel));
  jQuery("#impModal").modal("hide");
});
  
var element = function(elm, x, y, label) {
  var cell = new elm({
    position: { x: x, y: y },
    size: { width: 100, height: 40 },
    name:'parentCellClass',
    attrs: {
          text: {style: {fill: 'black','font-weight': 'bold'},text: 'Group', 'ref-y': -10, 'font-size': 10},
          rect: {
              'stroke-width': '2',
              'stroke-opacity': .7,
              stroke: 'grey',
              rx: 2,
              ry: 2,
              fill: 'transparent',
              'fill-opacity': .5
          },
    }
  });
  graph.addCell(cell);
  return cell;
};
//modify path
jQuery("#btn-modify").click(function(){
  var hiddenId = document.getElementById("param-id").value;
  var getCellById = graph.getCell(hiddenId);
  var updateFilePath = document.getElementById("filePathVal").value;
  var cellView = paper.findViewByModel(getCellById);
  cellView.model.attributes.filePath = updateFilePath;
  //console.log(cellView.model.attributes.filePath);
});
//modify path
jQuery("#btn-filter-form").click(function(){
  jQuery("#filterModal").modal("show");
});
graph.on('change:source change:target', function(link) {
    var sourcePort = link.get('source');
    var sourcePortId = sourcePort.id;
    var targetId = link.get('target').id;
    var getSourceCell = graph.getCell(sourcePortId);
    getSourceCell.prop('ports/groups/out/attrs/.port-body/fill', 'yellow');
    console.log('need connection');
    if(targetId){
    getSourceCell.prop('ports/groups/out/attrs/.port-body/fill', '#ccd6d6');
    console.log(getSourceCell);
    var fileUrl = getSourceCell.attributes.filePath;
    var filename = fileUrl.split('/').pop();
    console.log('connected');
    if(filename){
    	updateheader_filter(filename);
    }
    
    
    }
});
//restricting child elements in group
graph.on('change:position', function(cell) {
  var parentId = cell.get('parent');
  if (!parentId) return;
  var parent = graph.getCell(parentId);
  var parentBbox = parent.getBBox();
  var cellBbox = cell.getBBox();
  if (parentBbox.containsPoint(cellBbox.origin()) &&
      parentBbox.containsPoint(cellBbox.topRight()) &&
      parentBbox.containsPoint(cellBbox.corner()) &&
      parentBbox.containsPoint(cellBbox.bottomLeft())) {
      return;
  }
  // Revert the child position.
  cell.set('position', cell.previous('position'));
});
//Save graph
jQuery('#btn-save').click(function () {

   jsonSave = JSON.stringify(graph);
   var graph_nid = '<?php echo $graph_nid; ?>';
   //console.log(graph_nid);
   save_graph(graph_nid, jsonSave);
});
//Save graph
jQuery('#btn-run').click(function () {
	var filename = 'data.csv';
	read_source_file(filename);
});
//current graph data
var current_graph_data = '<?php echo $current_graph_data;?>';
if(current_graph_data){
  graph.fromJSON(JSON.parse(current_graph_data));
}
//Ajax request for node save
 function save_graph(graph_nid, jsonSave) {

  jQuery.ajax({
        url : '/joint-save',
        data : {
          graph_nid : graph_nid,
          jsonSave : jsonSave
        },
        beforeSend : function() {
          jQuery(".graphLoader-save").css('visibility','visible');
        },
        type : 'post',
        success : function(data) {
          jQuery(".graphLoader-save").css('visibility','hidden');
          jQuery("#msgModal").modal("show");
        },
        error : function(xhr, status, error) {
          // executed if something went wrong during call
          if (xhr.status > 0)
            alert('got error: ' + status);
        }
      });
};
//Ajax request for reading headers
 function read_source_file(filename) {

  jQuery.ajax({
        url : '/reading-source',
        data : {
          filename : filename
        },
        beforeSend : function() {
        },
        type : 'post',
        success : function(data) {
          //jQuery(".graphLoader-save").css('visibility','hidden');
          //jQuery("#sourceTableModal").modal("show");
          var parseData =  JSON.parse(data);
          console.log(parseData);
      //     for(i=0; i< parseData.length; i++ ){
      //     	var option = document.createElement("option");
		    // option.setAttribute("value", parseData[i]);
		    // option.text = parseData[i];
		    // sourceAttrFilter.appendChild(option);

      //     }
        },
        error : function(xhr, status, error) {
          // executed if something went wrong during call
          if (xhr.status > 0)
            alert('got error: ' + status);
        }
      });
};
//Ajax request for reading headers
 function updateheader_filter(filename) {

  jQuery.ajax({
        url : '/reading-headers',
        data : {
          filename : filename
        },
        beforeSend : function() {
        },
        type : 'post',
        success : function(data) {
          //jQuery(".graphLoader-save").css('visibility','hidden');
          //jQuery("#sourceTableModal").modal("show");
          var parseData =  JSON.parse(data);
          //console.log(parseData);
          for(i=0; i< parseData.length; i++ ){
          	var option = document.createElement("option");
		    option.setAttribute("value", parseData[i]);
		    option.text = parseData[i];
		    sourceAttrFilter.appendChild(option);

          }
        },
        error : function(xhr, status, error) {
          // executed if something went wrong during call
          if (xhr.status > 0)
            alert('got error: ' + status);
        }
      });
};
});
/////jquery for left panel
jQuery(".user-nav-slide").click(function () {

    if (jQuery("#operator-rel").hasClass("closed")) {
      jQuery("#operator-area").show('medium');
      jQuery(".user-nav-slide").animate({"left": "232px"}, "medium");
      jQuery("#operator-rel").removeClass("closed");
    } else {
  
      jQuery("#operator-area").hide('medium');
      jQuery(".user-nav-slide").animate({"left": "0px"}, "medium");
      jQuery("#operator-rel").addClass("closed");
    }
  });
//jquery for right panel
jQuery(".user-nav-slide-right").click(function () {

  if (jQuery("#parameter-rel").hasClass("closed")) {
      
    jQuery(".user-nav-slide-right").animate({"right": "232px"});
    jQuery("#parameters-box").hide();
    jQuery("#parameter-area").show('medium');
    jQuery("#parameters").show('medium');
    jQuery("#parameter-rel").removeClass("closed");
  }
  else {
    jQuery(".user-nav-slide-right").animate({"right": "0px"});
    jQuery("#parameter-area").hide('medium');
    jQuery("#parameter-rel").addClass("closed");
  }
});
</script>

<?php } ?>