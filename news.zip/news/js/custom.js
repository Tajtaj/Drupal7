(function($) {
  $(document).ready(function(){
    $(".dropdown-toggle").dropdown();
    }); // document ready close
   
    
})(jQuery);     // (function($) close